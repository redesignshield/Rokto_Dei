# Feature Specification

## F-01 Account registration
**User story:** As a person, I want to create one account so I can search for blood and optionally register as a donor.

**Rules:** Email/password; verification required for donor search/contact; no phone OTP in MVP.

**Acceptance:** Unverified account cannot access protected donor contact data. Verified account can log in across web and Android using the same UID.

## F-02 Single profile with multiple capabilities
**User story:** As a user, I want to be both a donor and a blood seeker without duplicate accounts.

**Rules:** One `users/{uid}` record. Donor-specific data can be stored in a linked donor profile or donor subdocument, but it must use the same UID. Blood request ownership also references this UID.

**Acceptance:** User can enable/disable donor listing and create a blood request without another account.

## F-03 Donor enrollment
Fields: name, phone number, blood group, division, district, upazila, optional photo, optional last donation date, contact methods, consent.

Phone number is not verified in MVP. UI must not show a phone-verified badge.

## F-04 Availability
Options:
- Available
- Temporarily Unavailable
- Not Specified (default)

Donor can change status at any time. No daily reminder or mandatory update. Store update timestamp. Inactive accounts remain unless donor/admin disables them or policy requires action.

## F-05 Donor search
Filters: blood group (required), division/district/upazila (optional), availability (optional).
Sort: relevance/location; do not imply clinical compatibility.
Counts: total active listed donors and marked-Available donors are separate.

## F-06 Contact
Donor chooses Call, SMS, WhatsApp and/or IMO. Only enabled methods appear.
No public/private toggle. No per-request donor approval.
Contact phone is protected from anonymous/public access and made available only to signed-in, email-verified users through secure backend authorization.
The donor must explicitly consent to this access when enabling donor listing/contact.
A signed-in user may copy/share the number; this residual risk must be disclosed.

## F-07 Blood request (conditional P0/P1)
Fields: blood group, units, location, hospital, required date/time, requester contact, description, status. Expiry and report moderation required.

## F-08 Reports
Report reasons: incorrect phone, abusive contact, fake profile, spam, misleading availability, other. Admin reviews and records action.

## F-09 Admin
Role-based permissions, server-side authorization, audit log. Admin can suspend/restore accounts and hide donor listings.

## F-10 Localization and accessibility
Bengali-first labels, English-ready localization architecture, readable contrast, keyboard/screen-reader support, clear loading/empty/error states.
