# Project Overview — রক্তদেই (Rokto Dei)

## 1. পরিচিতি
**নাম:** রক্তদেই (Rokto Dei)  
**ধরন:** Blood Donor Finder & Connection Platform  
**প্রাথমিক বাজার:** বাংলাদেশ  
**প্ল্যাটফর্ম:** Android application, responsive website, admin dashboard  
**প্রধান ভাষা:** বাংলা; English support পরবর্তী/সমান্তরাল release-এ।

## 2. সমস্যা
জরুরি সময়ে রোগী বা স্বজনের নির্দিষ্ট রক্তের গ্রুপ ও এলাকার উপযুক্ত রক্তদাতা খুঁজে পাওয়া এবং দ্রুত যোগাযোগ করা কঠিন হতে পারে। অনলাইন পোস্টে পুরোনো/ভুল তথ্য, অনিশ্চিত availability এবং যোগাযোগের অসুবিধা থাকে।

## 3. সমাধান
একটি searchable donor directory এবং blood-request workflow, যেখানে user blood group ও location দিয়ে donor খুঁজবেন, donor profile দেখবেন এবং donor-নির্বাচিত Call/SMS/WhatsApp/IMO channel ব্যবহার করে সরাসরি যোগাযোগ করবেন।

## 4. Product principles
- দ্রুত, সহজ, mobile-first ব্যবহার।
- এক ব্যক্তির একটি account; একই account donor ও blood seeker উভয় কাজ করতে পারবে।
- Donor registration ঐচ্ছিক এবং যেকোনো সময় চালু/বন্ধ করা যাবে।
- Donor availability নিজের ইচ্ছায় যেকোনো সময় update করবেন; daily activity বাধ্যতামূলক নয়।
- Donor offline থাকলেও contact attempt করা যাবে।
- In-app chat থাকবে না।
- Privacy ও server-side security শুরু থেকেই বাস্তবায়ন করতে হবে।
- কোনো donor-এর availability বা medical eligibility নিশ্চিত বলে দাবি করা যাবে না।

## 5. Success measures
- Email-verified account registration completion rate.
- Donor registration completion rate.
- Blood group/location search success rate.
- Contact action click-through (Call/SMS/WhatsApp/IMO)।
- Incorrect number/report rate.
- Duplicate/fake/spam account rate.
- Blood request resolution rate (শুধু user-reported; medically verified outcome নয়)।
- Crash-free sessions এবং Android/Web functional parity.

## 6. Stakeholders
- Product owner/project sponsor: TBD
- End users: blood seekers, donors, family members
- Operations/admin team: TBD
- Development/QA: TBD
- Legal/privacy reviewer: TBD

## 7. Assumptions
- Firebase is the proposed backend, subject to cost and security review.
- Email/password authentication with email verification is MVP.
- Phone OTP is deferred because of current cost constraints.
- Phone number is required for a donor contact profile, but number ownership is not verified in MVP.
- Users must understand that unverified phone numbers may be wrong or outdated.

## 8. Key risks
- Unverified phone numbers can prevent emergency contact.
- Donor availability can become outdated.
- Contact details can be copied/shared by signed-in users.
- Fake accounts, harassment, scraping and spam.
- Users may mistake email verification for identity verification.
- Legal/privacy obligations and data retention need local review.

## 9. Release strategy
Release a limited MVP after security, privacy, Android and web acceptance tests. Start with controlled pilot users and monitor incorrect-number reports, abuse, crashes and search quality before broad promotion.
