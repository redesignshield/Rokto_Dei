# Business Requirements Document (BRD)

## 1. Business objective
বাংলাদেশে রক্তপ্রার্থী ও স্বেচ্ছায় রক্তদানে আগ্রহী ব্যক্তিদের মধ্যে দ্রুত যোগাযোগের সুযোগ তৈরি করা।

## 2. Business outcomes
1. User সহজে account খুলতে পারবেন।
2. User চাইলে একই account-এ donor profile চালু করতে পারবেন।
3. Patient blood group ও area দিয়ে donor খুঁজতে পারবেন।
4. Patient donor-এর নির্বাচিত contact channel ব্যবহার করতে পারবেন।
5. Admin abuse, inaccurate information এবং account reports পরিচালনা করতে পারবেন।

## 3. User groups
- Registered user: search ও request তৈরি করতে পারে।
- Donor-enabled user: donor details ও contact preferences পরিচালনা করতে পারে।
- Admin/moderator: অনুমোদিত administrative actions করতে পারে।

এগুলো আলাদা account type নয়। একই user একাধিক কাজ করতে পারবেন।

## 4. Business requirements
| ID | Requirement | Priority |
|---|---|---|
| BR-01 | Email/password registration, login এবং email verification | P0 |
| BR-02 | One account supports both donor and blood-seeker journeys | P0 |
| BR-03 | Optional donor profile registration | P0 |
| BR-04 | Blood group and location based donor search | P0 |
| BR-05 | Donor can update availability whenever they choose | P0 |
| BR-06 | Donor can choose Call/SMS/WhatsApp/IMO channels | P0 |
| BR-07 | Signed-in, email-verified users can access donor contact details through authorized backend flow | P0 |
| BR-08 | Donor count must distinguish registered donors from currently marked Available donors | P0 |
| BR-09 | Basic report/block/moderation workflow | P0 |
| BR-10 | Admin role enforced server-side | P0 |
| BR-11 | Blood request creation and status management | P1 unless approved for MVP |
| BR-12 | Phone OTP verification | Future |
| BR-13 | Push notifications | P1 |
| BR-14 | Hospital/blood-bank directory | P2 |

## 5. Business rules
- Email must be verified before a user can use donor search/contact features.
- Email verification does not verify identity, phone number, medical fitness or donor eligibility.
- Donor status defaults to `not_specified`.
- No automatic removal due only to inactivity.
- No daily availability update requirement.
- A donor may use the app as a patient without creating a second account.
- A user may disable donor listing while retaining their account.
- Only donor-selected contact methods appear on their profile.
- No in-app chat in the initial product.
- Donor must provide explicit consent before their phone/contact information is made available to eligible signed-in users.
- Donor contact is not a guarantee of response or blood availability.
- Transfusion decisions and crossmatching must be handled by qualified medical professionals.

## 6. Constraints
- Phone OTP is not in MVP due to cost.
- Phone number ownership cannot be claimed as verified.
- Backend and security implementation must not expose private phone data through public queries.
- Android and website must use the same source of truth.

## 7. Acceptance / business sign-off
The product owner must approve:
- MVP feature boundary.
- Contact number visibility/access policy.
- Whether blood request module is P0 or P1.
- Location granularity and supported administrative areas.
- Legal documents and data retention policy.
