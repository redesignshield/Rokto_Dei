# Project Scope

## In scope — MVP
- Android app and responsive website.
- Shared Firebase backend.
- Email/password registration, login, email verification and password reset.
- One account/profile per person.
- Optional donor enrollment within the same account.
- Blood group and division/district/upazila fields.
- Donor availability management at any time.
- Donor search and counts.
- Donor-selected Call/SMS/WhatsApp/IMO methods.
- Secure contact-data access for signed-in, email-verified users.
- Basic admin dashboard and role protection.
- Basic report and moderation functions.
- Bengali-first UI.
- Security, QA and deployment documentation.

## Out of scope — MVP
- In-app chat, messaging inbox or voice/video calls.
- Mandatory daily donor check-in.
- Automatic donor removal because of inactivity.
- Phone OTP/SMS authentication (future).
- AI-based medical matching or diagnosis.
- Guarantee of blood availability or medical eligibility.
- Payment, donations or fundraising.
- Hospital integration unless separately approved.
- Complex map/live GPS tracking.
- Automated identity verification unless a real verification provider/process is selected.

## Conditional scope
Blood Request module: recommended for the product, but should be explicitly prioritized as P0 or P1 before implementation. If included, it needs moderation, expiry, status lifecycle and abuse controls.

## Deliverables
- Source code repository.
- Android build artifact.
- Deployed website.
- Admin dashboard.
- Firebase configuration and security rules.
- Test evidence.
- User-facing privacy policy and terms after legal review.
- Operational handover and maintenance guide.

## Change control
Any feature outside this scope requires a written change request describing user value, cost, security/privacy impact, implementation effort and acceptance criteria.
