# Software Requirements Specification (SRS)

## 1. System scope
Rokto Dei consists of:
1. Android app (Capacitor wrapper or selected native-compatible approach).
2. Responsive web application.
3. Admin dashboard.
4. Shared backend, authentication and database.

## 2. User states
- `registered_unverified`
- `registered_verified`
- `donor_enabled`
- `suspended`
- `deactivated`

Donor status is a profile attribute, not a separate authentication role.

## 3. Functional requirements

### Authentication
- FR-001: Register with email and password.
- FR-002: Send email verification.
- FR-003: Restrict donor search/contact until email is verified.
- FR-004: Login/logout.
- FR-005: Password reset.
- FR-006: Account deactivation/deletion request.

### User and donor profile
- FR-010: Maintain one user profile per authenticated UID.
- FR-011: User can enable donor profile without creating another account.
- FR-012: Store blood group and Bangladesh location fields.
- FR-013: Donor can edit their profile.
- FR-014: Donor can disable donor listing.
- FR-015: Donor can set availability to `available`, `temporarily_unavailable`, or `not_specified`.
- FR-016: Donor may change availability at any time; no scheduled update requirement.
- FR-017: Record `lastAvailabilityUpdatedAt`.

### Search
- FR-020: Search active donor profiles by blood group.
- FR-021: Filter by division, district and upazila.
- FR-022: Display total matching registered donors separately from donors marked Available.
- FR-023: Never infer Available from recent login or app activity.
- FR-024: Exclude disabled, suspended and deleted donor profiles.

### Contact
- FR-030: Donor selects one or more contact methods: call, SMS, WhatsApp, IMO.
- FR-031: Only selected contact buttons are displayed.
- FR-032: Contact information is accessible only to authenticated, email-verified users through authorized backend access.
- FR-033: No per-contact approval request is required; donor consent is captured when enabling contact visibility.
- FR-034: Call/SMS/WhatsApp/IMO launch the appropriate device app/deep link where supported.
- FR-035: If the target app is unavailable or deep link fails, show a safe fallback (e.g. copy number or open web link) only if consent and platform policy permit.
- FR-036: Log contact action metadata only where necessary; do not record call/SMS content.

### Requests (if included in MVP)
- FR-040: Verified user can create a blood request.
- FR-041: Owner can edit/cancel/mark fulfilled.
- FR-042: Request has status and expiry.
- FR-043: Admin can moderate reported/spam requests.

### Administration
- FR-050: Admin can view/manage accounts and donor profiles according to permission.
- FR-051: Admin can review reports.
- FR-052: Admin actions are audit logged.
- FR-053: Admin privileges are assigned and checked server-side.

## 4. Non-functional requirements
- NFR-001 Security: deny by default; least privilege.
- NFR-002 Privacy: minimize collection and exposure of personal data.
- NFR-003 Performance: common donor search should return within 3 seconds under agreed pilot load (target to validate).
- NFR-004 Availability: service uptime target to be agreed before production.
- NFR-005 Accessibility: readable typography, contrast, touch targets and screen-reader labels.
- NFR-006 Localization: Bengali-first; avoid hard-coded UI strings.
- NFR-007 Compatibility: agreed Android versions and modern mobile/desktop browsers.
- NFR-008 Reliability: handle offline, network timeout, duplicate submissions and retry safely.
- NFR-009 Auditability: record privileged administrative changes.
- NFR-010 Maintainability: typed models, modular services, documented environment configuration.

## 5. Data validation
- Validate email format and Firebase verification state.
- Normalize phone numbers to E.164 where possible; Bangladesh country code `+880` handling must be tested.
- Validate supported blood groups.
- Validate location against a maintained Bangladesh administrative-area dataset.
- Validate contact methods against an allowlist.
- Do not accept role/admin fields from untrusted client writes.

## 6. Error states
- Email not verified.
- Account suspended/deactivated.
- No donors found.
- Donor profile incomplete.
- Contact method unavailable on device.
- Invalid or missing phone number.
- Network unavailable/timeout.
- Permission denied.
- Request expired/closed.
- Backend unavailable.

## 7. Open decisions
- Is Blood Request P0 or P1?
- Is phone number mandatory at donor enrollment or only when at least one contact channel is enabled?
- Will contact number be returned by a callable Cloud Function or a narrowly scoped protected document read?
- Exact Android minimum SDK/browser support.
- Production retention/deletion periods.
