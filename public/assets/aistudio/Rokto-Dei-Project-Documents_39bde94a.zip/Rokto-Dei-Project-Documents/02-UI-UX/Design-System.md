# Design System — Initial Direction

## Brand
Name: রক্তদেই (Rokto Dei)  
Personality: trustworthy, calm, urgent when necessary, inclusive, simple.

## Visual direction
Red and white base, clean cards, restrained use of rounded corners, clear blood-group labels. Avoid excessive decoration, alarming animations or clutter.

## Suggested initial tokens (subject to design review)
- Primary: `#D71920`
- Primary dark: `#A90F18`
- Background: `#FFF7F7`
- Surface: `#FFFFFF`
- Text: `#202124`
- Muted text: `#666666`
- Success: accessible green
- Warning: accessible amber
- Error: accessible red

## Typography
Use a Bengali-capable font with reliable Android/web rendering (e.g. Noto Sans Bengali). Define fallback fonts. Test all blood group labels and numbers.

## Components
- Primary and secondary buttons
- Blood group chips
- Donor result card
- Availability badge
- Email verified badge
- Contact method buttons
- Search filters
- Form fields with validation
- Empty/loading/error states
- Confirmation dialog
- Report form

## Accessibility
- WCAG 2.2 AA target for web where practical.
- Do not rely on color alone for status.
- Adequate text contrast.
- Touch targets suitable for mobile.
- Screen-reader labels and focus states.
- Support font scaling.

## Responsive breakpoints
Define breakpoints during implementation and test narrow Android devices, tablets and desktop browsers. Do not hard-code only one viewport.

## Content tone
Use simple, respectful Bengali. Emergency copy must be clear and must not promise donor response or medical outcome.
