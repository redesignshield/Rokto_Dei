# User Flows

## A. Registration
Home → Register → Email/password → Verification email → Verify → Login → User Home.

Unverified users see a resend-verification action and clear explanation.

## B. Become a donor
User Home → Enable Donor Profile → Explain contact-data use → Consent → Enter phone/blood group/location → Select contact methods → Set availability (default Not Specified) → Save → Donor profile listed.

## C. Search and contact
Login/verified → Find Donors → Select blood group → Add area filters → Results and separate counts → Open donor profile → Select enabled contact method → Native dialer/SMS/app opens.

No donor online status or immediate approval is required.

## D. Change availability
My Profile → Donor Settings → Availability → Choose status → Save → Updated timestamp stored.

## E. Patient also a donor
Same account → Search donors or create request. Donor profile remains attached to the same UID. No second registration.

## F. Blood request (if included)
Home → Create Blood Request → Enter required details → Review privacy notice → Submit → Manage request → Mark fulfilled/cancelled. Request expires according to configured policy.

## G. Report donor
Donor profile → Report → Select reason and optional details → Submit → Confirmation → Admin review.

## H. Admin moderation
Admin dashboard → Reports queue → Inspect relevant data → Take action → Add reason → Audit log entry.

## UX rules
- Keep the main search action prominent.
- Avoid requiring donor daily activity.
- Do not label email verification as identity verification.
- Clearly distinguish registered donor count from Available status count.
- Always display availability uncertainty.
- Contact actions must disclose that phone number may be visible to the recipient where required.
