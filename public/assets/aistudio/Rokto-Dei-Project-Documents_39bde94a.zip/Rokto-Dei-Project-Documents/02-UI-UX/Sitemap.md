# Sitemap

## Public / unauthenticated
- Landing / Home
- About Rokto Dei
- How It Works
- Safety & Disclaimer
- Login
- Register
- Email verification notice
- Privacy Policy
- Terms and Conditions

## Authenticated user
- Home / Dashboard
- Find Donors
  - Blood group selection
  - Location filters
  - Search results
  - Donor profile
  - Contact actions
- My Profile
  - Personal details
  - Account settings
- Donor Settings (same account)
  - Enable/disable donor listing
  - Donor details
  - Availability
  - Contact methods
  - Consent
- Blood Requests (if enabled)
  - Create request
  - My requests
  - Request details
  - Edit/close request
- Reports / Help
- Logout

## Admin
- Admin login (same auth system, separate authorization)
- Overview
- Users
- Donors
- Blood requests
- Reports
- Moderation queue
- Audit logs
- Configuration

Admin routes must be protected server-side; hiding links is not authorization.
