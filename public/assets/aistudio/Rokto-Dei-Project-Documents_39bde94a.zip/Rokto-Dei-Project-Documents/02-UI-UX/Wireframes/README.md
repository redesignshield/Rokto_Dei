# Low-fidelity Wireframes

These are structural wireframes, not final visual designs.

## 1. Home
[Header: Logo | Login/Profile]
[Main: আপনার কোন রক্তের গ্রুপ প্রয়োজন?]
[Blood group grid: A+ A- B+ B- AB+ AB- O+ O-]
[Location filters: Division / District / Upazila]
[Search Donors button]
[Optional: Create Blood Request]
[How it works | Safety | Footer]

## 2. Search Results
[Selected group + area]
[Count: Total listed donors]
[Count: Marked Available]
[Filter / Sort]
[Donor card: Name | Blood group | Area | Availability | Email Verified]
[View Profile]

## 3. Donor Profile
[Photo optional]
[Name]
[Blood group]
[Area]
[Email Verified label]
[Availability + last updated]
[Enabled contact actions: Call / SMS / WhatsApp / IMO]
[Report profile]

## 4. My Profile
[Personal profile]
[Edit account details]
[Donor profile: Enable / Disable]
[Availability selector]
[Contact method checkboxes]
[Phone number field]
[Consent explanation]
[Save]

## 5. Admin Dashboard
[Summary metrics]
[Users | Donors | Requests | Reports]
[Search/filter table]
[Record detail + permitted actions]
[Audit history]

## UX caveat
Do not display phone number to anonymous visitors. Contact actions are only available after authentication and email verification. The backend must enforce this rule.
