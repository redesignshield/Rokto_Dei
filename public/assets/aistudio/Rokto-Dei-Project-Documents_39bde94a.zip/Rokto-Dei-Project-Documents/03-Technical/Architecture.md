# Technical Architecture

## 1. Proposed architecture
- Client: React + TypeScript + Vite.
- Android packaging: Capacitor, subject to native deep-link validation.
- Backend: Firebase Authentication, Cloud Firestore, Cloud Functions.
- Hosting: Firebase Hosting or an approved equivalent.
- Notifications: Firebase Cloud Messaging in a later phase.
- Shared services/models between web and Android.

Technology choices are recommendations, not proof that a Firebase project has been configured.

## 2. Logical components
1. Authentication module
2. User profile module
3. Donor profile module
4. Search/query module
5. Contact resolver
6. Blood request module (if approved)
7. Reporting/moderation module
8. Admin authorization module
9. Audit logging module

## 3. Identity model
`users/{uid}` is the canonical account. Donor data is linked to the same UID, e.g. `donors/{uid}`. A person does not create a separate patient account. Blood requests use `createdBy: uid`.

## 4. Contact data protection
Recommended approach:
- Store donor phone number in a protected donor document or private subcollection.
- Do not include phone number in public/search result documents.
- Search function returns only non-sensitive fields.
- Contact resolver Cloud Function checks Firebase Auth UID, email verification, account status, donor listing status and consent.
- Only then returns the minimum contact fields needed for enabled methods.
- Rate-limit and log contact-data access metadata.
- Never log phone number in analytics or ordinary application logs.
- Admin access must be permission-scoped and audited.

Firebase Auth email verification claim freshness must be considered; verify current user state/token and force refresh/re-authentication as appropriate. Do not rely on a client-supplied `emailVerified: true` field.

## 5. Search architecture
Search by exact blood group and normalized location IDs. Use indexes for supported filter combinations. Avoid downloading the full donor collection to filter on client. Counts should be computed safely (Firestore aggregation or backend-maintained counters) and must exclude disabled/suspended donors.

## 6. Security boundaries
- Firestore rules deny by default.
- Admin privileges from trusted server-controlled claims/roles only.
- Validate every write on server/rules.
- App Check recommended for supported clients, but not a substitute for authorization.
- Rate limit sensitive endpoints.
- Restrict CORS and API access where relevant.
- Keep secrets out of client bundle.
- Separate dev/staging/production Firebase projects.
- Backups and recovery process required before launch.

## 7. Contact deep links
- Call: `tel:` URI.
- SMS: `sms:` URI.
- WhatsApp: official supported `wa.me`/app link format using normalized international number.
- IMO: confirm supported official deep-link scheme at implementation time; do not invent a URI scheme. Provide safe fallback if unavailable.
- Test on real Android devices and supported browsers.
- Do not automatically send messages or initiate calls.

## 8. Environments and configuration
Use environment-specific config, Firebase project IDs, API endpoints and feature flags. Do not commit service-account keys or private credentials. Client Firebase config is not a secret, but security depends on rules and authorization.

## 9. Observability
Crash reporting, structured error logs, security event logs, uptime checks and admin audit trails. Avoid collecting unnecessary personal data.
