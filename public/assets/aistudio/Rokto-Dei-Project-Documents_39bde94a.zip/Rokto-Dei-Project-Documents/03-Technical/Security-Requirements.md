# Security Requirements

## Authentication and account integrity
- Firebase Auth is the identity source.
- Require verified email for donor search/contact.
- Phone OTP is not enabled in MVP; phone ownership is unverified.
- Use secure password reset and account recovery.
- Prevent account enumeration where practical.
- Apply abuse/rate limits to registration, search and contact resolution.

## Authorization
- Deny by default.
- Enforce ownership checks on every user/donor/request write.
- Admin permissions must be server-controlled and never self-assigned.
- Admin dashboard UI hiding is not security.
- Contact data must never be included in public donor search results.

## Contact privacy
- Donor explicitly consents when enabling donor contact listing.
- No public/private toggle in product UI.
- Only signed-in, email-verified users may obtain contact details through protected backend flow.
- Disclose that recipients may copy/share a displayed number.
- Donor can disable listing or remove/change contact methods.
- Log access metadata with retention limits; do not store call/SMS contents.

## Data protection
- Minimize personal data.
- No exact home address or precise GPS in public profile.
- Encrypt data in transit; use platform encryption at rest.
- Restrict Firebase Storage rules.
- Do not log passwords, tokens, phone numbers or sensitive payloads.
- Define deletion, backup and retention procedures.

## Application security
- Validate and sanitize all inputs.
- Protect against injection, XSS, CSRF where applicable, insecure direct object references and mass assignment.
- Rate-limit sensitive functions.
- Use Firebase App Check as an additional control where feasible.
- Keep dependencies updated and scan for vulnerabilities.
- Separate dev/staging/production environments.

## Admin security
- Strong unique admin accounts.
- MFA for admins where available.
- Least-privilege roles.
- Audit all privileged actions.
- Review admin access periodically.

## Operational security
- Incident response contact and escalation path.
- Backup/restore test before launch.
- Monitor unusual contact lookups, scraping and repeated reports.
- Have a process to disable compromised accounts and revoke sessions.

## Important trust labels
- `Email Verified` means email verified only.
- Never label a user `Identity Verified` without actual identity checks.
- Never label a donor `Phone Verified` in MVP.
- Never imply medical fitness or blood availability has been verified.
