# Database Schema — Proposed Firestore Model

This is a logical schema. Field types and indexes must be finalized during implementation.

## `users/{uid}` — account profile
- `uid`: string
- `fullName`: string
- `email`: string (consider relying on Auth as source of truth)
- `accountStatus`: `active | suspended | deactivated`
- `createdAt`: timestamp
- `updatedAt`: timestamp
- `preferredLanguage`: `bn | en`

Do not store client-editable admin role here.

## `donors/{uid}` — optional donor profile, same account UID
- `uid`: string
- `isListed`: boolean
- `bloodGroup`: enum (`A+`, `A-`, `B+`, `B-`, `AB+`, `AB-`, `O+`, `O-`)
- `divisionId`: string
- `districtId`: string
- `upazilaId`: string
- `availability`: `available | temporarily_unavailable | not_specified`
- `lastAvailabilityUpdatedAt`: timestamp
- `contactMethods`: array from allowlist (`call`, `sms`, `whatsapp`, `imo`)
- `contactConsentAt`: timestamp
- `createdAt`: timestamp
- `updatedAt`: timestamp
- `lastDonationDate`: optional date
- `photoPath`: optional storage path

## `donorPrivate/{uid}` — restricted contact data
- `uid`: string
- `phoneNumber`: normalized string
- `phoneNumberUpdatedAt`: timestamp

This collection must not be readable directly by ordinary clients. Contact resolver controls access. If donor phone is required to enable any contact method, enforce it.

## `bloodRequests/{requestId}` — if module is approved
- `createdBy`: uid
- `bloodGroup`: enum
- `units`: number
- `divisionId`, `districtId`, `upazilaId`: strings
- `hospitalName`: string
- `requiredAt`: timestamp
- `requesterContact`: protected field/reference
- `status`: `open | fulfilled | cancelled | expired`
- `expiresAt`: timestamp
- `createdAt`, `updatedAt`: timestamps

## `reports/{reportId}`
- `reportedBy`: uid
- `targetUid`: uid
- `reason`: enum
- `description`: string (length-limited)
- `status`: `open | reviewing | resolved | dismissed`
- `createdAt`: timestamp
- `reviewedBy`: optional admin UID
- `reviewedAt`: optional timestamp

## `adminRoles/{uid}` — server-managed
- `role`: `admin | moderator`
- `permissions`: array
- `createdAt`: timestamp
Only trusted admin tooling/server may write.

## `auditLogs/{logId}`
- `actorUid`
- `action`
- `targetType`
- `targetId`
- `reason`
- `createdAt`
No unnecessary contact data or secrets.

## Data rules
- `users/{uid}`: user may read/update only permitted own fields.
- `donors/{uid}`: owner may edit own permitted donor fields; search access must expose only safe fields.
- `donorPrivate/{uid}`: no direct client read; contact resolver only.
- Admin access is server-authorized and audited.
- Do not trust client-provided `emailVerified`, `role`, `isAdmin` or counters.
- Phone number is unverified in MVP; do not display a phone-verified badge.
- Deletion/deactivation must handle linked donor data and requests according to retention policy.

## Indexes
Create composite indexes only for actual search combinations, e.g. bloodGroup + isListed + districtId + upazilaId + availability. Validate query plans and Firestore limits.
