# API / Service Interface Documentation

No production API is currently deployed. The following are proposed logical operations, to be implemented as Cloud Functions or equivalent authenticated services.

## Authentication (Firebase Auth)
- `registerWithEmail(email, password)`
- `sendEmailVerification()`
- `signInWithEmail(email, password)`
- `sendPasswordReset(email)`
- `signOut()`

## User profile
- `getMyProfile()`
- `updateMyProfile(profilePatch)`
- `requestAccountDeactivation()`

## Donor profile
- `enableDonorProfile(donorData, consent)`
- `updateDonorProfile(donorPatch)`
- `setDonorListingEnabled(isListed)`
- `updateAvailability(status)`
- `updateContactMethods(methods)`
- `disableDonorProfile()`

## Search
`searchDonors({ bloodGroup, divisionId?, districtId?, upazilaId?, availability? , pageSize?, cursor? })`

Response must contain safe fields only:
- donor UID/reference
- display name
- blood group
- general area
- availability
- last availability update
- email verified indicator derived from trusted Auth state where appropriate

Never return phone number in search results.

## Contact resolver
`getDonorContact({ donorUid, requestedMethod })`

Authorization:
1. Caller authenticated.
2. Caller email verification confirmed from trusted Auth token/account state.
3. Caller account active.
4. Target donor exists, is listed and active.
5. Donor has consented to contact disclosure.
6. Requested method is enabled.
7. Phone/contact data exists and passes format validation.
8. Rate limit and abuse checks pass.

Response returns only the minimum data required for the selected method. Record access metadata, not message/call content.

## Reports
- `reportDonor({ targetUid, reason, description? })`
- `getMyReports()` (only if user-facing status is required)

## Blood requests (if approved)
- `createBloodRequest(payload)`
- `updateOwnBloodRequest(requestId, patch)`
- `closeOwnBloodRequest(requestId, status)`
- `searchBloodRequests(filters)`

## Admin operations
- `adminListUsers(filters, cursor)`
- `adminUpdateAccountStatus(uid, status, reason)`
- `adminListDonors(filters, cursor)`
- `adminReviewReport(reportId, action, reason)`
- `adminListAuditLogs(filters, cursor)`

Every admin operation must verify server-side role and permission.

## Common response/error model
- `UNAUTHENTICATED`
- `EMAIL_NOT_VERIFIED`
- `PERMISSION_DENIED`
- `NOT_FOUND`
- `INVALID_ARGUMENT`
- `RESOURCE_EXHAUSTED`
- `FAILED_PRECONDITION`
- `INTERNAL`

Use pagination, input validation, idempotency for retryable writes and safe error messages. Never expose stack traces or private data in client errors.
