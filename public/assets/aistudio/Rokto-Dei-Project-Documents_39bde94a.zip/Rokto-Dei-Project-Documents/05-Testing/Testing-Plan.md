# Testing Plan

## Objectives
Verify functional correctness, privacy, security, accessibility, performance and Android/web compatibility.

## Test levels
1. Unit tests: validation, formatting, status logic, permission helpers.
2. Integration tests: Auth, Firestore, Functions, contact resolver.
3. Security rules tests: allowed and denied access.
4. End-to-end tests: registration through donor search/contact.
5. Device/browser tests: Android and responsive web.
6. Regression tests: every fixed defect.
7. UAT: representative donors and blood seekers.

## Test environments
- Local Firebase Emulator Suite.
- Staging Firebase project with synthetic data.
- Production smoke tests with test accounts only.

Never use real patient data in development test fixtures.

## Critical scenarios
- Unverified email cannot search/contact.
- Verified account can search.
- Same account can act as donor and blood seeker.
- Donor status can be changed at any time.
- No daily update is required.
- Not Specified is not counted as Available.
- Inactive donor is not automatically deleted.
- Disabled donor is excluded from search.
- Anonymous client cannot read donor phone.
- Search response never contains phone number.
- Contact resolver rejects unverified/unauthorized users.
- Contact resolver rejects disabled methods.
- Admin-only actions reject ordinary users.
- Donor can remove listing and contact methods.
- App handles missing WhatsApp/IMO and invalid phone number.
- Network failure does not create duplicate requests.
