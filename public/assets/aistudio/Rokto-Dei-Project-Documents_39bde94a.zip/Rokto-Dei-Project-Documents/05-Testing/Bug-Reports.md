# Bug Reports

## Bug report template
- Bug ID:
- Title:
- Reported by:
- Date/time:
- App version/build:
- Platform/device/browser:
- Environment:
- Preconditions:
- Steps to reproduce:
- Expected result:
- Actual result:
- Frequency:
- Severity: Critical / High / Medium / Low
- Priority: P0 / P1 / P2
- Logs/screenshots:
- Personal data removed: Yes/No
- Suspected area:
- Fix summary:
- Regression test:
- Status: New / Triaged / In Progress / Fixed / Verified / Closed

## Severity guide
- Critical: data breach, unauthorized admin access, core service unavailable.
- High: authentication/contact/search core flow broken.
- Medium: feature partially broken with workaround.
- Low: cosmetic or minor usability issue.

## Privacy rule
Never attach real phone numbers, passwords, access tokens, patient records or other unnecessary personal data to bug reports.
