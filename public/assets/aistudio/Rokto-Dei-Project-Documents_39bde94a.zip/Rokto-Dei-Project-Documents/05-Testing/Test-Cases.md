# Test Cases

| ID | Scenario | Expected result |
|---|---|---|
| TC-001 | Register with valid email/password | Account created; verification email sent |
| TC-002 | Login with unverified email | Protected donor features blocked with clear message |
| TC-003 | Verify email and login | Protected features available |
| TC-004 | Create donor profile from existing user | Donor profile uses same UID; no second account |
| TC-005 | Search without donor enrollment | User can still search as blood seeker |
| TC-006 | Donor default availability | `not_specified` |
| TC-007 | Change availability | New value and server timestamp saved |
| TC-008 | Donor remains offline for weeks | Profile is not automatically removed |
| TC-009 | Search by blood group and district | Only matching active listed donors returned |
| TC-010 | Count donors | Total and Available counts are separate |
| TC-011 | Search result payload inspection | No phone number returned |
| TC-012 | Anonymous read of private donor contact | Denied |
| TC-013 | Verified user uses enabled Call method | Device dialer opens with correct number |
| TC-014 | Disabled contact method selected | Request rejected / button absent |
| TC-015 | WhatsApp unavailable | Safe fallback message/action shown |
| TC-016 | IMO deep link unsupported | No broken or invented URI; safe fallback |
| TC-017 | User attempts to set admin role | Denied |
| TC-018 | Ordinary user calls admin function | Permission denied |
| TC-019 | User edits another donor profile | Denied |
| TC-020 | Donor disables listing | Excluded from search |
| TC-021 | Report incorrect number | Report created and visible to authorized admin |
| TC-022 | Admin resolves report | Action recorded in audit log |
| TC-023 | Same account creates blood request | Request owner UID matches user UID |
| TC-024 | Android and web update same profile | Consistent data shown on both platforms |

## Evidence
For each test record:
- Test ID
- Build/version
- Environment
- Test account type
- Steps
- Expected result
- Actual result
- Pass/Fail
- Screenshot/log reference (remove personal data)
- Tester/date
