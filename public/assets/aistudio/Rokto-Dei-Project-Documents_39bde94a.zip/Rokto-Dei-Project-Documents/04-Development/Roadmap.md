# Development Roadmap

A suggested sequence; timeline depends on team capacity and testing. Do not treat week estimates as guarantees.

## Phase 0 — Decisions and setup
- Approve MVP scope and open decisions.
- Create repository and dev/staging Firebase projects.
- Establish coding standards and environment setup.
- Confirm Bangladesh location dataset.

## Phase 1 — Foundation
- React/TypeScript/Vite project.
- Shared routing, layout and localization.
- Firebase initialization.
- Environment configuration.
- CI checks and basic error handling.

## Phase 2 — Authentication
- Register/login/logout.
- Email verification and resend.
- Password reset.
- Protected routes.
- Account state handling.

## Phase 3 — Single user profile and donor enrollment
- One UID-based user profile.
- Optional donor profile.
- Blood group and location.
- Donor listing enable/disable.
- Availability selector and timestamp.
- Contact methods and explicit consent.

## Phase 4 — Search and contact
- Search/filter/indexes.
- Correct donor counts.
- Protected contact resolver.
- Call/SMS/WhatsApp/IMO integration.
- Android real-device and web testing.

## Phase 5 — Admin and reporting
- Secure admin authorization.
- User/donor management.
- Report queue and moderation.
- Audit logs.

## Phase 6 — Blood requests (if approved)
- Create/manage requests.
- Expiry and moderation.
- Request search and status.

## Phase 7 — Hardening and release
- Security rules tests.
- Functional, integration and regression tests.
- Accessibility and performance.
- APK signing and release build.
- Website deployment.
- Backup/monitoring/incident procedures.
- Pilot launch and feedback.

## Release gate
No production launch until contact data protection, admin authorization, account recovery, rules tests and real-device contact flows pass.
