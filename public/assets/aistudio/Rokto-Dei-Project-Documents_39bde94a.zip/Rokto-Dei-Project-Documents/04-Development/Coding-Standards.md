# Coding Standards

## General
- TypeScript strict mode.
- Prefer small, focused modules and reusable services.
- Keep UI components separate from data access and business logic.
- Avoid duplicated business rules between web and Android.
- Use explicit types for Firestore documents and API responses.
- No `any` unless justified and documented.
- Handle loading, empty, success and error states.

## Security
- Never trust client-provided roles, emailVerified flags, counters or ownership IDs.
- Never put service-account credentials or secrets in frontend code.
- Do not fetch private donor phone data in general search queries.
- Validate inputs on client and server.
- Use least-privilege Firestore/Storage rules.

## React
- Use functional components and hooks.
- Keep components accessible.
- Avoid unnecessary global state.
- Centralize route guards and authorization UX, while keeping backend enforcement authoritative.

## Data and time
- Use server timestamps for authoritative audit/update timestamps.
- Normalize phone numbers consistently.
- Use stable location IDs, not free-text-only location matching.
- Paginate search results.
- Handle duplicate requests and retries safely.

## Naming
- Components: PascalCase.
- Functions/variables: camelCase.
- Constants: UPPER_SNAKE_CASE where appropriate.
- Firestore collection names: consistent plural camelCase.

## Testing
- Unit test validation and business rules.
- Integration test Auth, Firestore and Cloud Functions with emulators where possible.
- Test security rules for both allowed and denied cases.
- Test Android contact intents on real devices.
- Add regression tests for every fixed bug.
