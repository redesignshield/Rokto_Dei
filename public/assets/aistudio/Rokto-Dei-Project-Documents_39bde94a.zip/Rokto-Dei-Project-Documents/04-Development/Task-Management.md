# Task Management

## Workflow
`Backlog → Ready → In Progress → Code Review → QA → Done`

Blocked tasks use `Blocked` with a reason. Do not mark Done until acceptance criteria and tests are recorded.

## Priority
- P0: release blocker / core MVP.
- P1: important post-MVP.
- P2: future enhancement.

## Task template
- ID:
- Title:
- User value:
- Scope:
- Files/modules:
- Dependencies:
- Security/privacy impact:
- Acceptance criteria:
- Test evidence:
- Owner:
- Status:
- Notes/known limitations:

## Initial backlog
| ID | Task | Priority |
|---|---|---|
| RD-001 | Confirm open product decisions | P0 |
| RD-002 | Create repository and environments | P0 |
| RD-003 | Set up frontend foundation | P0 |
| RD-004 | Implement Firebase Auth and email verification | P0 |
| RD-005 | Implement single user profile | P0 |
| RD-006 | Implement optional donor enrollment | P0 |
| RD-007 | Implement availability controls | P0 |
| RD-008 | Implement protected donor search | P0 |
| RD-009 | Implement secure contact resolver | P0 |
| RD-010 | Implement Call/SMS/WhatsApp/IMO actions | P0 |
| RD-011 | Implement reports and admin authorization | P0 |
| RD-012 | Test Firestore rules and backend permissions | P0 |
| RD-013 | Decide/implement blood request module | P1 |
| RD-014 | Add FCM notifications | P1 |
| RD-015 | Evaluate phone OTP | P2 |

## AI-assisted development rule
For each task, AI must inspect the existing code first, propose a minimal plan, modify only relevant files, run available tests, and report exact changed files and actual test outcomes. Never claim tests passed if not executed.
