# Terms and Conditions — Review Draft

**Service:** রক্তদেই (Rokto Dei)  
**Effective date:** To be set  
**Operator:** [Insert legal operator details]

> IMPORTANT: This is a drafting template, not legal advice. Obtain review by a Bangladesh-qualified lawyer before publication. Replace every placeholder.

## 1. Acceptance
By accessing or using Rokto Dei, you agree to these Terms and the Privacy Policy. If you do not agree, do not use the service.

## 2. Service description
Rokto Dei helps users discover listed blood donors and contact them through donor-selected contact methods. It is a connection platform only, not a hospital, blood bank, medical provider or emergency medical service.

## 3. No medical guarantee
Rokto Dei does not guarantee that a donor will respond, be available, have a particular blood type, be medically eligible or successfully donate. Blood group, compatibility, crossmatching and donor eligibility must be confirmed by qualified medical professionals and appropriate healthcare facilities.

## 4. User responsibilities
Users agree to:
- Provide accurate information and keep it updated.
- Use the platform only for genuine blood-related purposes.
- Respect donors and recipients.
- Not harass, threaten, spam, scrape or misuse contact details.
- Not impersonate another person.
- Not submit false requests or misleading availability information.
- Protect their login credentials.

## 5. Donor responsibilities
Donors control their listing, availability and contact methods. Donors must understand that selecting contact methods and enabling listing makes relevant contact information available to eligible signed-in users. Phone number ownership is not verified by OTP in the initial release.

Donors may change availability or disable listing at any time. Availability status is self-reported and may be outdated.

## 6. Contact and privacy
Contact details are provided for the purpose of blood-related communication. Users must not redistribute, sell or misuse them. Once a phone number is displayed, the recipient may be able to copy or share it; users should exercise care.

## 7. Accounts and suspension
We may restrict, suspend or remove accounts that violate these Terms, submit false information, abuse other users or create security risks. Admin actions should be proportionate and recorded.

## 8. Third-party services
Call, SMS, WhatsApp, IMO, email and hosting services are provided by third parties and are subject to their own terms, availability and privacy practices. Rokto Dei does not control those services.

## 9. Availability and service changes
We may modify, suspend or discontinue features for maintenance, security, legal or operational reasons. We do not guarantee uninterrupted service.

## 10. Limitation and liability
The exact limitation of liability, disclaimers and consumer protections must be drafted by counsel to comply with applicable Bangladesh law. Do not publish a blanket exclusion that conflicts with mandatory law.

## 11. Reporting and disputes
Users can report inaccurate contact information, abusive behavior or fake profiles. Provide an operator support channel and a documented review process.

## 12. Governing law
[Have Bangladesh-qualified counsel specify governing law, jurisdiction, dispute resolution and mandatory consumer/privacy provisions.]

## 13. Contact
[Insert legal operator name, address and support email.]
