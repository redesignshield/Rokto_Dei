# Privacy Policy — Review Draft

**Service:** রক্তদেই (Rokto Dei)  
**Effective date:** To be set before publication  
**Operator/legal entity:** [Insert legal operator name and address]  
**Contact:** [Insert privacy contact email]

> IMPORTANT: This is a drafting template, not legal advice. It must be reviewed and finalized by a Bangladesh-qualified lawyer/privacy professional before publication. Do not publish with placeholders.

## 1. Information we collect
Depending on features used, Rokto Dei may collect:
- Account email and authentication identifiers.
- Name and profile details.
- Donor blood group and general location (division/district/upazila).
- Phone number and selected contact methods when a user enables donor listing.
- Availability status and update timestamp.
- Blood request details and requester contact details, if request feature is enabled.
- Reports, moderation records and security/audit events.
- Technical diagnostics needed to operate and secure the service.

We should not collect exact home address, precise location, date of birth or identity documents unless a separately justified feature and lawful basis are approved.

## 2. How information is used
- Create and maintain accounts.
- Show donor search results.
- Enable donor-seeker contact using donor-selected methods.
- Manage blood requests if enabled.
- Prevent spam, fraud, harassment and misuse.
- Provide support, maintain security and improve reliability.
- Meet applicable legal obligations.

## 3. Donor contact information
A donor who enables donor listing and contact methods gives consent for their phone/contact information to be made available to authenticated, email-verified Rokto Dei users for the selected contact purposes. Phone number is not phone-OTP-verified in the initial release.

Recipients may be able to copy, save or share a number after it is displayed. Rokto Dei cannot guarantee that a recipient will keep it confidential. Donors can disable listing or remove contact methods, subject to lawful retention needs.

## 4. Verification limitations
Email verification confirms control of an email address. It does not confirm legal identity, phone ownership, blood group, medical fitness or ability to donate.

## 5. Sharing
Information may be shared:
- With other authenticated, email-verified users only as required for donor search/contact and according to donor consent.
- With service providers (e.g. hosting/authentication) under appropriate safeguards.
- With authorized moderators/admins for support, security and abuse handling.
- When required by applicable law or valid legal process.

Do not sell personal information. Final sharing terms require legal review.

## 6. Retention and deletion
Define retention periods before launch. Account deletion should remove or de-identify information where legally and operationally possible. Certain fraud-prevention, security, audit or legal records may need limited retention. Publish exact periods only after review.

## 7. Security
We use access controls and technical safeguards, but no online service can guarantee absolute security. Report suspected misuse or data exposure to [privacy contact].

## 8. Children
The service's minimum age and parental-consent policy must be decided and legally reviewed before launch. Do not assume minors can independently register as donors.

## 9. User rights and choices
Users should be able to review/update their profile, disable donor listing, change contact methods, request account deletion and contact the operator regarding their information, subject to applicable law.

## 10. Changes and contact
We may update this policy. Material changes should be communicated appropriately. Contact: [Insert email and postal/contact details].
