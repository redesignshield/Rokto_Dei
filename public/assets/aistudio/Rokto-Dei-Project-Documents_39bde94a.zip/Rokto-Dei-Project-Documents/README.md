# রক্তদেই (Rokto Dei) — Project Documentation

এই ফোল্ডারে রক্তদেই Android App, Website এবং Admin Dashboard-এর প্রাথমিক Project Documentation রয়েছে।

## কীভাবে ব্যবহার করবেন
1. প্রথমে `01-Project-Planning/Project-Overview.md`, `Project-Scope.md` এবং `BRD.md` পড়ুন।
2. এরপর `SRS.md` ও `Feature-Specification.md` যাচাই করে MVP-এর scope স্থির করুন।
3. UI/UX ও Technical ডকুমেন্টগুলো দেখে Architecture এবং Screen Flow অনুমোদন করুন।
4. Google AI Studio-তে development শুরু করার আগে প্রতিটি সিদ্ধান্ত/অনুমোদন এই ডকুমেন্টে আপডেট করুন।
5. `TBD` বা `Open Decision` লেখা বিষয়গুলো বাস্তবায়নের আগে সিদ্ধান্ত নিতে হবে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি একটি প্রাথমিক, implementation-ready baseline; বাস্তব Firebase project, API, domain, hosting, legal entity বা production configuration এখনো সরবরাহ করা হয়নি।
- `API-Documentation.md`-এ প্রস্তাবিত interface আছে; deploy করা API-এর দাবি করা হচ্ছে না।
- `Privacy-Policy.md` ও `Terms-and-Conditions.md` হলো review draft, প্রকাশের আগে বাংলাদেশি আইনজীবী/যোগ্য privacy professional দিয়ে যাচাই করাতে হবে।
- Email verification কেবল email address-এর নিয়ন্ত্রণ যাচাই করে; পরিচয়, ফোন নম্বর বা রক্তদানের যোগ্যতা যাচাই করে না।
- Phone OTP MVP-তে অন্তর্ভুক্ত নয়।
- In-app chat থাকবে না।

## Product decisions captured
- One account/profile per person; একই user donor এবং blood seeker—দুই কাজই করতে পারবেন।
- Donor হওয়া ঐচ্ছিক; user পরে donor registration চালু করতে পারবেন।
- Availability donor নিজের ইচ্ছায় যেকোনো সময় বদলাতে পারবেন; বাধ্যতামূলক daily update নেই।
- Availability: Available / Temporarily Unavailable / Not Specified; default Not Specified.
- Donor contact methods: Direct Call, SMS, WhatsApp, IMO; donor নিজে নির্বাচন করবেন।
- Public/Private phone visibility toggle নেই। Phone number শুধু signed-in, email-verified app users-দের জন্য server-authorized contact flow দিয়ে প্রকাশ/ব্যবহারযোগ্য হবে।
- Patient/donor approval request per contact নেই; emergency contact যেন donor online থাকার ওপর নির্ভর না করে।
- Android + responsive website + admin dashboard একই backend ব্যবহার করবে।
