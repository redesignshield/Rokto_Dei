# Maintenance Plan

## 1. Routine maintenance
- Monitor app crashes, function errors and hosting availability.
- Review security alerts and unusual contact lookups.
- Review abuse reports and incorrect phone reports.
- Keep dependencies and Android build tooling updated.
- Check Firebase usage, quotas and billing.
- Verify backups and perform restore drills.
- Review admin accounts and permissions.
- Review privacy-policy/terms changes when product behavior changes.

## 2. Incident response
1. Detect and classify incident.
2. Contain affected account, endpoint or feature.
3. Preserve relevant logs without exposing unnecessary personal data.
4. Assess data and user impact.
5. Notify project owner and legal/privacy contact.
6. Make legally required notifications within applicable deadlines.
7. Patch, test and deploy.
8. Document root cause and prevention actions.

## 3. Backup and recovery
- Define Firestore export schedule and retention.
- Secure backup access separately from app admins.
- Test restore process periodically.
- Document recovery time and recovery point objectives before production.

## 4. Release management
- Use development, staging and production environments.
- Test database/rules migrations in staging.
- Keep signed release artifacts and rollback instructions.
- Run smoke tests after deployment.

## 5. Support operations
- Define support email/contact.
- Triage wrong-number reports, harassment and fake accounts.
- Establish escalation for urgent safety concerns.
- Publish support response expectations only when operationally achievable.

## 6. Maintenance ownership
Project owner: TBD  
Technical owner: TBD  
Security contact: TBD  
Privacy/legal contact: TBD
